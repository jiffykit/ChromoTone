# Welcome to ChromoTone

ChromoTone is an experimenta microtonal harmonic instrument and music environment focused on exploration, touch, color, movement and musical intuition.

This version runs entirely locally on your machine.

## Windows Users

Please keep all files together in the same folder.

Do not move, rename or separate files after extracting the package, otherwise certain functions may fail to load correctly.

## Launching ChromoTone

Run:

FULLSCREEN.bat

This launches ChromoTone in an optimized fullscreen browser environment with settings tuned for:
- smoother audio playback
- higher memory limits
- lower latency
- better visual performance
- increased simultaneous sound handling

Google Chrome is currently the recommended browser.

## Browser Compatibility

### Recommended
- Google Chrome
- Chromium

These currently provide the best compatibility, lowest audio latency and highest stability for ChromoTone.

### Usually Works Well
- Microsoft Edge
- Brave
- Opera

These are Chromium-based browsers and should work similarly to Chrome, although some versions may apply additional memory-saving or tab-throttling features that can affect performance.

### Limited / Experimental
- Firefox

Firefox may experience:
- reduced simultaneous sound playback
- timing inconsistencies
- graphical slowdowns
- WebAudio limitations
- UI scaling differences
- higher latency

Some advanced features may behave differently or not function correctly in Firefox.

## Offline Use

Once downloaded, ChromoTone does not require an internet connection to run in this form.

## Recommended System

- Windows 10 or newer
- Modern CPU strongly recommended
- 8GB RAM minimum
- 16GB RAM recommended for larger projects
- Dedicated audio hardware or headphones recommended
- Touchscreen optional but highly recommended

## Performance Notes

ChromoTone can generate large amounts of simultaneous audio and visual activity.

Performance depends heavily on:
- browser
- CPU speed
- available RAM
- graphics hardware
- audio drivers
- number of active voices and effects

If you push extremely dense harmonies, many loops, rapid modulation or large visual activity simultaneously, performance may eventually degrade depending on your system.

This is normal for a realtime experimental audio environment.

## Tips For Better Performance

If audio crackles, visuals stutter or timing becomes unstable:

- Close unnecessary browser tabs
- Close background applications
- Relaunch using FULLSCREEN.bat
- Reduce visual density
- Reduce simultaneous sustained notes
- Reduce extremely large looping structures
- Avoid leaving many inactive loops running
- Use Chrome or Chromium-based browsers
- Restart the browser occasionally during long sessions

Laptop battery-saving modes may also reduce audio performance significantly - keep plugged in!!

## Simultaneous Sound Limits

Browsers impose practical limits on realtime audio voices and processing.

While ChromoTone is optimized to handle large numbers of simultaneous sounds, extremely dense arrangements may eventually:
- increase CPU usage
- introduce latency
- reduce responsiveness
- create audio dropouts, glitches, pops or timing drops

The exact limit depends on your hardware and browser.

## What Is ChromoTone?

ChromoTone is not a traditional DAW.

It is a visual and tactile harmonic environment designed for:
- microtonal exploration
- chord exploration
- composition
- improvisation
- ear training
- experimental harmony
- live performance
- musical discovery

Instead of treating music like spreadsheets and menus, ChromoTone approaches harmony as something physical, visual and playable.

## Experimental Software Notice

ChromoTone is currently experimental software and active development is ongoing.

Some systems may change rapidly between versions and occasional bugs, instability or unexpected behavior may occur.

Saving backups of important work is strongly recommended.

## Reporting Bugs / Beta Testing

If you encounter a bug, please report it to:

fastfastmusic@gmail.com

Helpful bug reports greatly improve development.

Please include as much detail as possible:

### Include:
- what you were trying to do
- exactly what happened
- whether the issue is repeatable
- the browser used
- Windows / OS version
- screenshots if possible
- screen recordings if possible
- any error messages shown
- whether audio was affected
- approximate number of loops/chords active at the time

### Especially Helpful:
- step-by-step instructions to reproduce the bug
- whether it happens every time or randomly
- whether restarting fixes it
- whether fullscreen mode was active
- whether touch or mouse input was used

Example:

1. Opened ChromoTone
2. Loaded loop mode
3. Added 12 sustained chords
4. Dragged chord resize rapidly
5. Audio began crackling
6. Browser became unresponsive

Detailed reports / screenshots  are extremely valuable.


## Credits

Designed and created with love by James Mulvale (FASTFAST)
(c) 2025-2026 ALL RIGHTS RESERVED

Built through experimentation, iteration and an unhealthy number of late nights.
